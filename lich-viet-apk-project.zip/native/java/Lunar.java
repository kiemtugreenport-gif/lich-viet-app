package vn.lichviet.app.widget;

public class Lunar {
    static final double PI = Math.PI, TZ = 7;
    static final String[] CAN = {"Giáp","Ất","Bính","Đinh","Mậu","Kỷ","Canh","Tân","Nhâm","Quý"};
    static final String[] CHI = {"Tý","Sửu","Dần","Mão","Thìn","Tỵ","Ngọ","Mùi","Thân","Dậu","Tuất","Hợi"};

    static int jd(int d, int m, int y) {
        int a = (14 - m) / 12, yy = y + 4800 - a, mm = m + 12 * a - 3;
        return d + (153 * mm + 2) / 5 + 365 * yy + yy / 4 - yy / 100 + yy / 400 - 32045;
    }
    static double newMoon(int k) {
        double T = k / 1236.85, T2 = T * T, T3 = T2 * T, r = PI / 180;
        double J = 2415020.75933 + 29.53058868 * k + 0.0001178 * T2 - 0.000000155 * T3;
        J += 0.00033 * Math.sin((166.56 + 132.87 * T - 0.009173 * T2) * r);
        double M = 359.2242 + 29.10535608 * k - 0.0000333 * T2 - 0.00000347 * T3;
        double P = 306.0253 + 385.81691806 * k + 0.0107306 * T2 + 0.00001236 * T3;
        double F = 21.2964 + 390.67050646 * k - 0.0016528 * T2 - 0.00000239 * T3;
        double C = (0.1734 - 0.000393 * T) * Math.sin(M * r) + 0.0021 * Math.sin(2 * r * M)
            - 0.4068 * Math.sin(P * r) + 0.0161 * Math.sin(r * 2 * P) - 0.0004 * Math.sin(r * 3 * P)
            + 0.0104 * Math.sin(r * 2 * F) - 0.0051 * Math.sin(r * (M + P)) - 0.0074 * Math.sin(r * (M - P))
            + 0.0004 * Math.sin(r * (2 * F + M)) - 0.0004 * Math.sin(r * (2 * F - M))
            - 0.0006 * Math.sin(r * (2 * F + P)) + 0.001 * Math.sin(r * (2 * F - P)) + 0.0005 * Math.sin(r * (2 * P + M));
        double dt = T < -11 ? 0.001 + 0.000839 * T + 0.0002261 * T2 - 0.00000845 * T3 - 0.000000081 * T * T3
                            : -0.000278 + 0.000265 * T + 0.000262 * T2;
        return J + C - dt;
    }
    static double sunLong(double j) {
        double T = (j - 2451545) / 36525, T2 = T * T, r = PI / 180;
        double M = 357.5291 + 35999.0503 * T - 0.0001559 * T2 - 0.00000048 * T * T2;
        double L0 = 280.46645 + 36000.76983 * T + 0.0003032 * T2;
        double D = (1.9146 - 0.004817 * T - 0.000014 * T2) * Math.sin(r * M)
            + (0.019993 - 0.000101 * T) * Math.sin(r * 2 * M) + 0.00029 * Math.sin(r * 3 * M);
        double L = (L0 + D) * r;
        return L - PI * 2 * Math.floor(L / (PI * 2));
    }
    static int sl(int n) { return (int) Math.floor(sunLong(n - 0.5 - TZ / 24) / PI * 6); }
    static int nmd(int k) { return (int) Math.floor(newMoon(k) + 0.5 + TZ / 24); }
    static int m11(int y) {
        int off = jd(31, 12, y) - 2415021;
        int k = (int) Math.floor(off / 29.530588853);
        int n = nmd(k);
        if (sl(n) >= 9) n = nmd(k - 1);
        return n;
    }
    static int leapOff(int a) {
        int k = (int) Math.floor((a - 2415021.076998695) / 29.530588853 + 0.5);
        int l, i = 1, x = sl(nmd(k + i));
        do { l = x; i++; x = sl(nmd(k + i)); } while (x != l && i < 14);
        return i - 1;
    }
    /** Trả về {ngày, tháng, năm, nhuận(0/1), số ngày Julian} */
    public static int[] lunar(int d, int m, int y) {
        int n = jd(d, m, y), k = (int) Math.floor((n - 2415021.076998695) / 29.530588853);
        int ms = nmd(k + 1);
        if (ms > n) ms = nmd(k);
        int a = m11(y), b = a, ly;
        if (a >= ms) { ly = y; a = m11(y - 1); } else { ly = y + 1; b = m11(y + 1); }
        int ld = n - ms + 1, diff = (int) Math.floor((ms - a) / 29.0), lm = diff + 11, leap = 0;
        if (b - a > 365) {
            int lo = leapOff(a);
            if (diff >= lo) { lm = diff + 10; if (diff == lo) leap = 1; }
        }
        if (lm > 12) lm -= 12;
        if (lm >= 11 && diff < 4) ly -= 1;
        return new int[]{ld, lm, ly, leap, n};
    }
    public static String yearName(int y) { return CAN[(y + 6) % 10] + " " + CHI[(y + 8) % 12]; }
    public static String dayName(int j) { return CAN[(j + 9) % 10] + " " + CHI[(j + 1) % 12]; }
}
