package vn.lichviet.app.widget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.RemoteViews;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Calendar;
import org.json.JSONArray;
import org.json.JSONObject;
import vn.lichviet.app.R;

public abstract class WidgetBase extends AppWidgetProvider {
    static final String[] WD = {"Chủ nhật","Thứ hai","Thứ ba","Thứ tư","Thứ năm","Thứ sáu","Thứ bảy"};
    static final String[] WD_S = {"CN","T2","T3","T4","T5","T6","T7"};

    abstract int layout();
    abstract void fill(RemoteViews v, Info d);

    static class Info {
        int ld, lm, ly, leap, jdn;
        Calendar cal;
        String temp = "--°", emoji = "🌡️", desc = "Chưa có dữ liệu", range = "", city = "Hà Nội", next = "";
    }

    @Override
    public void onUpdate(final Context c, final AppWidgetManager m, final int[] ids) {
        render(c, m, ids);
        final PendingResult pr = goAsync();
        new Thread(new Runnable() {
            public void run() {
                try { if (refreshWeather(c)) render(c, m, ids); } catch (Exception e) { }
                pr.finish();
            }
        }).start();
    }

    @Override
    public void onReceive(Context c, Intent i) {
        super.onReceive(c, i);
        String a = i.getAction();
        if (Intent.ACTION_DATE_CHANGED.equals(a) || Intent.ACTION_TIME_CHANGED.equals(a) || Intent.ACTION_TIMEZONE_CHANGED.equals(a)) {
            AppWidgetManager m = AppWidgetManager.getInstance(c);
            int[] ids = m.getAppWidgetIds(new ComponentName(c, getClass()));
            render(c, m, ids);
        }
    }

    void render(Context c, AppWidgetManager m, int[] ids) {
        for (int id : ids) {
            RemoteViews v = new RemoteViews(c.getPackageName(), layout());
            fill(v, info(c));
            Intent li = c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());
            if (li != null) {
                v.setOnClickPendingIntent(R.id.root, PendingIntent.getActivity(c, 0, li, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT));
            }
            m.updateAppWidget(id, v);
        }
    }

    static Info info(Context c) {
        Info d = new Info();
        d.cal = Calendar.getInstance();
        int[] l = Lunar.lunar(d.cal.get(Calendar.DAY_OF_MONTH), d.cal.get(Calendar.MONTH) + 1, d.cal.get(Calendar.YEAR));
        d.ld = l[0]; d.lm = l[1]; d.ly = l[2]; d.leap = l[3]; d.jdn = l[4];
        // mùng 1 / rằm kế tiếp
        for (int i = 0; i < 40; i++) {
            Calendar t = (Calendar) d.cal.clone();
            t.add(Calendar.DAY_OF_MONTH, i);
            int[] x = Lunar.lunar(t.get(Calendar.DAY_OF_MONTH), t.get(Calendar.MONTH) + 1, t.get(Calendar.YEAR));
            if (x[0] == 1 || x[0] == 15) {
                String n = x[0] == 1 ? "mùng 1" : "rằm";
                d.next = i == 0 ? "Hôm nay " + n + " âm lịch" : (x[0] == 1 ? "Mùng 1" : "Rằm") + " tháng " + x[1] + " · còn " + i + " ngày";
                break;
            }
        }
        SharedPreferences w = c.getSharedPreferences("lv_widget", Context.MODE_PRIVATE);
        d.city = cityParts(c)[2];
        if (w.contains("temp")) {
            d.temp = w.getInt("temp", 0) + "°";
            int code = w.getInt("code", 0);
            d.emoji = emoji(code);
            d.desc = text(code);
            d.range = "Thấp " + w.getInt("min", 0) + "° · Cao " + w.getInt("max", 0) + "° · Ẩm " + w.getInt("hum", 0) + "%";
        }
        return d;
    }

    static String[] cityParts(Context c) {
        String s = c.getSharedPreferences("CapacitorStorage", Context.MODE_PRIVATE).getString("wx_city", "21.0285|105.8542|Hà Nội");
        String[] p = s.split("\\|");
        return p.length >= 3 ? p : new String[]{"21.0285", "105.8542", "Hà Nội"};
    }

    static boolean refreshWeather(Context c) throws Exception {
        SharedPreferences w = c.getSharedPreferences("lv_widget", Context.MODE_PRIVATE);
        String[] p = cityParts(c);
        String key = p[0] + p[1];
        if (System.currentTimeMillis() - w.getLong("ts", 0) < 20 * 60 * 1000 && key.equals(w.getString("key", ""))) return false;
        String u = "https://api.open-meteo.com/v1/forecast?latitude=" + p[0] + "&longitude=" + p[1]
            + "&current=temperature_2m,relative_humidity_2m,weather_code&daily=temperature_2m_max,temperature_2m_min&timezone=auto&forecast_days=1";
        HttpURLConnection h = (HttpURLConnection) new URL(u).openConnection();
        h.setConnectTimeout(6000);
        h.setReadTimeout(6000);
        BufferedReader r = new BufferedReader(new InputStreamReader(h.getInputStream(), "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = r.readLine()) != null) sb.append(line);
        r.close();
        JSONObject j = new JSONObject(sb.toString());
        JSONObject cur = j.getJSONObject("current");
        JSONObject dl = j.getJSONObject("daily");
        w.edit()
            .putInt("temp", (int) Math.round(cur.getDouble("temperature_2m")))
            .putInt("hum", cur.getInt("relative_humidity_2m"))
            .putInt("code", cur.getInt("weather_code"))
            .putInt("max", (int) Math.round(dl.getJSONArray("temperature_2m_max").getDouble(0)))
            .putInt("min", (int) Math.round(dl.getJSONArray("temperature_2m_min").getDouble(0)))
            .putString("key", key)
            .putLong("ts", System.currentTimeMillis())
            .apply();
        return true;
    }

    static String emoji(int c) {
        if (c == 0) return "☀️";
        if (c <= 2) return "🌤️";
        if (c == 3) return "☁️";
        if (c == 45 || c == 48) return "🌫️";
        if (c >= 51 && c <= 57) return "🌦️";
        if (c >= 61 && c <= 67) return "🌧️";
        if (c >= 71 && c <= 77) return "❄️";
        if (c >= 80 && c <= 82) return "🌧️";
        if (c >= 95) return "⛈️";
        return "⛅";
    }
    static String text(int c) {
        if (c == 0) return "Trời quang";
        if (c <= 2) return "Ít mây";
        if (c == 3) return "Nhiều mây";
        if (c == 45 || c == 48) return "Sương mù";
        if (c >= 51 && c <= 57) return "Mưa phùn";
        if (c >= 61 && c <= 67) return "Có mưa";
        if (c >= 71 && c <= 77) return "Tuyết";
        if (c >= 80 && c <= 82) return "Mưa rào";
        if (c >= 95) return "Giông bão";
        return "Có mây";
    }
    static String lunarShort(Info d) { return d.ld + "/" + d.lm + (d.leap == 1 ? " nhuận" : ""); }
}
