package vn.lichviet.app.widget;

import android.widget.RemoteViews;
import java.util.Calendar;
import vn.lichviet.app.R;

public class WidgetLarge extends WidgetBase {
    int layout() { return R.layout.widget_large; }
    void fill(RemoteViews v, Info d) {
        v.setTextViewText(R.id.tv_solar, WD[d.cal.get(Calendar.DAY_OF_WEEK) - 1] + ", " + d.cal.get(Calendar.DAY_OF_MONTH) + "/" + (d.cal.get(Calendar.MONTH) + 1) + "/" + d.cal.get(Calendar.YEAR));
        v.setTextViewText(R.id.tv_big_lunar, String.valueOf(d.ld));
        v.setTextViewText(R.id.tv_lunar_sub, "Tháng " + d.lm + (d.leap == 1 ? " nhuận" : "") + " · Năm " + Lunar.yearName(d.ly));
        v.setTextViewText(R.id.tv_day_cc, "Ngày " + Lunar.dayName(d.jdn));
        v.setTextViewText(R.id.tv_wx, d.emoji + " " + d.temp);
        v.setTextViewText(R.id.tv_wx_desc, d.city + " · " + d.desc);
        v.setTextViewText(R.id.tv_wx_range, d.range);
        v.setTextViewText(R.id.tv_next, "🌕 " + d.next);
    }
}
