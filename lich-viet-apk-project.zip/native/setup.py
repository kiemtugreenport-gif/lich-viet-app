# Chạy trong thư mục dự án sau khi `npx cap add android`
import os, shutil
base = "android/app/src/main"
dst = base + "/java/vn/lichviet/app/widget"
os.makedirs(dst, exist_ok=True)
for f in os.listdir("native/java"):
    shutil.copy("native/java/" + f, dst)
shutil.copytree("native/res", base + "/res", dirs_exist_ok=True)
p = base + "/AndroidManifest.xml"
s = open(p, encoding="utf-8").read()
perms = ('<uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>\n'
         '    <uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM"/>\n    ')
if "POST_NOTIFICATIONS" not in s:
    s = s.replace("<application", perms + "<application", 1)
rc = open("native/receivers.xml", encoding="utf-8").read()
if "WidgetSmall" not in s:
    s = s.replace("</application>", rc + "    </application>", 1)
open(p, "w", encoding="utf-8").write(s)
print("Da them widget")
