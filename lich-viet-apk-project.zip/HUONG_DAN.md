# Lịch Việt – đóng gói APK (Capacitor)

Ứng dụng dùng thông báo gốc của Android nên vẫn nhắc mùng 1, rằm và các ngày bạn tạo kể cả khi đã tắt app.

## Cần cài trước
1. Node.js 18+ (https://nodejs.org)
2. Android Studio (https://developer.android.com/studio), mở lần đầu để nó tải Android SDK

## Các bước
Mở Terminal trong thư mục này:

    npm install
    npx cap add android
    npx cap sync android

Mở file `android/app/src/main/AndroidManifest.xml`, thêm 2 dòng này ngay trên thẻ `<application`:

    <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
    <uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM"/>

Sau đó:

    npx cap open android

Trong Android Studio: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
File nằm ở `android/app/build/outputs/apk/debug/app-debug.apk`. Gửi file này sang điện thoại, bật "Cài từ nguồn không xác định" rồi cài.

## Sau này sửa giao diện
Sửa `www/index.html`, rồi chạy `npx cap sync android` và build lại.

## Ghi chú
- App tự lên lịch thông báo cho 90 ngày tới mỗi lần mở, nên thỉnh thoảng hãy mở app để làm mới lịch nhắc.
- Nếu máy Xiaomi, Oppo, Vivo, Huawei... không nhận nhắc khi tắt app, vào Cài đặt > Pin > cho Lịch Việt chạy nền / tự khởi động.
- Đổi biểu tượng app: dùng Android Studio > File > New > Image Asset.
- Muốn xuất bản lên CH Play cần build bản Release có ký (Build > Generate Signed Bundle).

## Widget màn hình chính
Dự án có 3 widget gốc Android (thư mục `native/`): Nhỏ 2x2, Vừa 4x2, Lớn 4x4, hiện giờ, lịch dương, lịch âm, thời tiết (Open-Meteo, không cần khóa API). Script `native/setup.py` tự chép chúng vào dự án Android khi build.
Thêm widget: giữ lâu ở chỗ trống màn hình chính > Widget > Lịch Việt. Chọn thành phố trong app để widget hiện thời tiết đúng nơi.
